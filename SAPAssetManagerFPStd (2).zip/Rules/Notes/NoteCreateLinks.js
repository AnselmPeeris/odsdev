import {NoteLibrary as NoteLib} from './NoteLibrary';

export default function NoteCreateLinks(context) {

    return NoteLib.createLinks(context);
}
