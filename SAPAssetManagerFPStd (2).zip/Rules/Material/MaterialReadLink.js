export default function MaterialReadLink(context) {
    return "Materials('" + context.getClientData().MaterialNum + "')";
}
