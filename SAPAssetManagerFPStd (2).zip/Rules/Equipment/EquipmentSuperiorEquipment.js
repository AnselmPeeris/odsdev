import {ValueIfExists} from '../Common/Library/Formatter';
export default function EquipmentSuperiorEquipment(context) {
    return ValueIfExists(context.binding.SuperiorEquip);
}
