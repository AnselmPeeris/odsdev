import { GlobalVar } from '../Common/Library/GlobalCommon';

export default function MobileStatusNotificationTaskObjectType() {
    return GlobalVar.getAppParam().OBJECTTYPE.NotificationTask;
}
