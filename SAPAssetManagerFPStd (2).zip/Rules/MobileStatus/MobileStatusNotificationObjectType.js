import { GlobalVar } from '../Common/Library/GlobalCommon';

export default function MobileStatusNotificationObjectType() {
    return GlobalVar.getAppParam().OBJECTTYPE.Notification;
}
