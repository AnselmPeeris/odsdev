export default function FormatSuperiorFLOC(context) {
    return context.binding.SuperiorFuncLoc !== '' ? context.binding.SuperiorFuncLoc: '-';
}
