import isNotificationCreateEnabled from '../UserAuthorizations/Notifications/EnableNotificationCreate';
export default function NotificationIsSamePlanningPlant(context) {
    return isNotificationCreateEnabled(context);
}
