

export default function LAMIsEnabledMeasuringPoint(context) {
    let binding = context.binding;

    return (binding.PointType === 'L');

}
