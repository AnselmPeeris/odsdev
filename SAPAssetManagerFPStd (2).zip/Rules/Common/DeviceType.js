export default function DeviceType(context) {
    return context.nativescript.platformModule.device.deviceType;
}
